const _ = require('lodash')

// TODO: 依FP方式改寫，使用Lodash填填看下方function，小提示(times、repeat、join)
const answer = length => {
  let stars = ''
  for (let i = 0; i < length; i++) {
    for (let j = 0; j < length * 2 - 1; j++) {
      if (j <= length - 1 + i && j >= length - 1 -i) {
        stars += '*'
      } else {
        stars += ' '
      }
    }
    stars += '\n'
  }
  return stars
}

console.log(answer(3))

function refactorAnswer (length) {
  const createStars = length => _._______('*', length)
  const createBlanks = length => _._______(' ', length)
  const createStr = (length, index) => `${createBlanks(length - index - 1)}${createStars(index * 2 + 1)}`
  const result = _(length)
    ._______((i) => createStr(length, i))
    ._______('\n')
  return result
}

console.log(refactorAnswer(3))
