const CAR_BRAND_LIST = [
  { name: 'audi', id: '123' },
  { name: 'bmw', id: '234' },
  { name: 'ford', id: '987' },
  { name: 'honda', id: '434' },
  { name: 'lexus', id: '535' },
  { name: 'toyota', id: '765' }
]

const CAR_TYPE_DESCRIPTION_MAP = {
  sedan: '轎車',
  van: '箱型車',
  pickUp: '貨卡',
  suv: '運動休旅車',
  sportsCar: '跑車',
  convertible: '敞篷車'
}

const SALE_LIST = [
  { brandId: '123', year: '1990', model: 'A4', color: 'red', isImportedCar: true, type: 'sedan' },
  { brandId: '234', year: '2014', model: '530i', color: 'blue', isImportedCar: true, type: 'sedan' },
  { brandId: '234', year: '2019', model: 'M3', color: 'white', isImportedCar: true, type: 'sportsCar' },
  { brandId: '434', year: '2015', model: 'CR-V', color: 'other', isImportedCar: false, type: 'suv' },
  { brandId: '434', year: '2019', model: 'Civic', color: 'white', isImportedCar: false, type: 'sedan' },
  { brandId: '987', year: '2003', model: 'Transit', color: 'white', isImportedCar: true, type: 'van' },
  { brandId: '535', year: '2013', model: 'IS250', color: 'black', isImportedCar: true, type: 'sedan' },
  { brandId: '765', year: '2018', model: 'Hilux', color: 'white', isImportedCar: true, type: 'pickUp' },
  { brandId: '765', year: '2010', model: 'Camry', color: 'black', isImportedCar: false, type: 'sedan' }
] 

module.exports = { CAR_BRAND_LIST, CAR_TYPE_DESCRIPTION_MAP, SALE_LIST }
