// let and const
// TODO: 請用第11行console.log輸出 ['volvo', 'bmw']
function setCarList (carName) {
  var carList = []
  if (!!carName) {
    carList.push(carName)
  }
}
setCarList('volvo')
setCarList('bmw')
console.log(carList)

// TODO: 請用let與const改寫
function printCarList () {
  var carList = ['audi', 'bmw', 'ford', 'honda', 'lexus', 'toyota']
  for (var i = 0; i < carList.length; i++) {
    console.log(carList[i])
  }
  console.log('總共' + i + '個品牌')
}

printCarList()

