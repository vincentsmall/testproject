// default parameters
// TODO: 優化

/**
 * 結算金額
 * @param {number} price    價格 
 * @param {number} discount 折扣
 */
function calculatePayment (price, discount) {
  if (!price) { price = 0 }
  if (!discount) { discount = 0 }
  return price - (price * discount)
}

console.log(calculatePayment(100, 0.5))
