const { CAR_BRAND_LIST, CAR_TYPE_DESCRIPTION_MAP, SALE_LIST } = require('../testData')
const _ = require('lodash')

function printCarInfo (brandId, info) {
  const carBrand = _.find(CAR_BRAND_LIST, { id: brandId })
  const brand = carBrand.name
  // ======僅修改此區段======
  // TODO: 請取出 `info` 相關資料
  const year = info.year
  const model = info.model
  const color = info.color
  // TODO: `const type`不可修改，考慮使用別名處理
  const type = CAR_TYPE_DESCRIPTION_MAP[info.type]
  // =======================
  // 不可修改
  console.log(`品牌：${brand}\n車型：${type}\n年份：${year}\n型號：${model}\n車色：${color}\n`)
}

// TODO: 請用 `Destructing Assignment` 與 `rest params` 技巧取出 `brandId`、`isImportedCar`、`info`
function printImportedCarList (saleList) {
  _.forEach(saleList, function (carInfo) {
    // ======僅修改此區段======
    const brandId = carInfo.brandId
    const info = {
      year: carInfo.year,
      model: carInfo.model,
      color: carInfo.color,
      type: carInfo.type
    }
    const isImportedCar = carInfo.isImportedCar
    // =======================
    if (isImportedCar) printCarInfo(brandId, info)
  })
}

printImportedCarList(SALE_LIST)
