// template literals
// TODO: 請用console.log換行(\n)印出
// 白日依山盡，黃河入海流。
// 欲窮千里目，更上一層樓。
var text = '白日依山盡，黃河入海流。'
function printTangPoems (section1) {
  var section2 = '欲窮千里目，更上一層樓。'
  console.log(section1+section2)
}
printTangPoems(text)
