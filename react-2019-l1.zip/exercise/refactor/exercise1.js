const _ = require('lodash')

// TODO: 請運用es6、fp、lodash重構
function rocIDFormat (id) {
  if (!id) return false

  var city = [
    1, 10, 19, 28, 37, 46, 55, 64, 39, 73, 82, 2, 11,
    20, 48, 29, 38, 47, 56, 65, 74, 83, 21, 3, 12, 30
  ]
  id = id.toUpperCase()
  // 使用「正規表達式」檢驗格式
  if (!id.match(/^[A-Z](1|2)\d{8}$/i)) {
    return false
  } else {
    // 將字串分割為陣列(IE必需這麼做才不會出錯)
    id = id.split('')
    // 計算總分
    var total = city[id[0].charCodeAt(0) - 65]
    for (var i = 1; i <= 8; i++) {
      total += _.parseInt(id[i]) * (9 - i)
    }
    // 補上檢查碼(最後一碼)
    total += _.parseInt(id[9])
    // 檢查比對碼(餘數應為0)
    return (total % 10 === 0)
  }
}

rocIDFormat('A123456789') // true

rocIDFormat('A123456780') // false
