const { CAR_BRAND_LIST, CAR_TYPE_DESCRIPTION_MAP, SALE_LIST } = require('../testData')
const _ = require('lodash')

function printCarInfo (brandId, info) {
  const carBrand = _.find(CAR_BRAND_LIST, { id: brandId })
  const brand = carBrand.name
  const year = info.year
  const model = info.model
  const color = info.color
  const type = CAR_TYPE_DESCRIPTION_MAP[info.type]
  console.log(`品牌：${brand}\n車型：${type}\n年份：${year}\n型號：${model}\n車色：${color}\n`)
}


// 請用chain，將printImportedCarList與printCarInfo function合併執行，參考使用(map、keyBy、forEach、mapValues、filter)))
function printImportedCarList (saleList) {
  _.forEach(saleList, function (carInfo) {
    const brandId = carInfo.brandId
    const info = {
      year: carInfo.year,
      model: carInfo.model,
      color: carInfo.color,
      type: carInfo.type
    }
    const isImportedCar = carInfo.isImportedCar
    if (isImportedCar) printCarInfo(brandId, info)
  })
}

printImportedCarList(SALE_LIST)


// TODO: 填填看，使其結果相同
function answer (saleList) {
  const carBrandMap = _(_______).keyBy(_______).mapValues(_______).value()
  _(saleList)
    .filter(_______)
    .map(_______)
    .forEach(_______)
}

answer(SALE_LIST)

