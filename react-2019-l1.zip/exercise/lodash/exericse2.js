const { CAR_BRAND_LIST, SALE_LIST } = require('../testData')
const _ = require('lodash')

// TODO: 請用取出 `SALE_LIST` 中，進口車的品牌列表
function printImportBrandList (saleList) {
  const result = []// TODO
  console.log(result)
}

printImportBrandList(SALE_LIST) // ['audi', 'bmw', 'ford', 'lexus', 'toyota']
