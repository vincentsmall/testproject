ES6-FP-Lodash
